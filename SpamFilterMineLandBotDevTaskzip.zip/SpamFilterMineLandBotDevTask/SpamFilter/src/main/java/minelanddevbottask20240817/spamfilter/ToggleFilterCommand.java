package minelanddevbottask20240817.spamfilter;

import devcraft.ICommand;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.interactions.commands.build.OptionData;

import java.util.List;
import java.util.Objects;

public class ToggleFilterCommand implements ICommand {

    @Override
    public String getName() {
        return "togglefilter";
    }

    @Override
    public String getDescription() {
        return "Enable or disable the spam filter";
    }

    @Override
    public List<OptionData> getOptions() {
        return List.of(
                new OptionData(OptionType.BOOLEAN, "enable", "Whether to enable or disable the spam filter", true)
        );
    }

    @Override
    public void execute(SlashCommandInteractionEvent event) {
        boolean enable = Objects.requireNonNull(event.getOption("enable")).getAsBoolean();
        SpamFilterManager.setFilterState(Objects.requireNonNull(event.getGuild()).getId(), enable);
        String status = enable ? "enabled" : "disabled";
        event.reply("Spam filter has been " + status + ".").queue();
    }
}
