package minelanddevbottask20240817.spamfilter;


import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class SpamFilterListener extends ListenerAdapter {

    private static final Map<String, Long> lastMessageTime = new HashMap<>();

    @Override
    public void onMessageReceived(MessageReceivedEvent event) {
        if (event.getAuthor().isBot()) {
            return;
        }

        String guildId = event.getGuild().getId();
        if (!SpamFilterManager.isFilterEnabled(guildId)) {
            return;
        }

        long now = System.currentTimeMillis();
        String userId = event.getAuthor().getId();
        long lastMessageTimeMillis = lastMessageTime.getOrDefault(userId, 0L);

        if (now - lastMessageTimeMillis < 1000) {
            event.getMessage().delete().queue();

            event.getChannel().sendMessage(event.getAuthor().getAsMention() + " please do not spam!").queue(warningMessage ->
                    warningMessage.delete().queueAfter(5, TimeUnit.SECONDS)
            );
        }

        lastMessageTime.put(userId, now);
    }
}