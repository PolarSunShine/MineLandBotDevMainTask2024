package minelanddevbottask20240817.spamfilter;

import java.util.concurrent.ConcurrentHashMap;

public class SpamFilterManager {
    private static final ConcurrentHashMap<String, Boolean> filterStates = new ConcurrentHashMap<>();

    public static boolean isFilterEnabled(String guildId) {
        return filterStates.getOrDefault(guildId, false);
    }

    public static void setFilterState(String guildId, boolean enabled) {
        filterStates.put(guildId, enabled);
    }
}