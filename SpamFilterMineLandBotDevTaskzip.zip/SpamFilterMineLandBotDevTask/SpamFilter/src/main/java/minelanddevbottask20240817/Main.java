package minelanddevbottask20240817;

import minelanddevbottask20240817.spamfilter.SpamFilterListener;
import minelanddevbottask20240817.spamfilter.ToggleFilterCommand;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;

public class Main {
    public static void main(String[] args) {
        JDA jda = JDABuilder.createLight("MTI3NDMyODUxODE3MTU1NzkzOQ.GKB1LI.RszG0s6CMiow_ZkRxhyGdIM0ekjhMLxY5CidHw\n")
                .build();

        CommandManager manager = new CommandManager();

        jda.addEventListener(manager);

        manager.add(new ToggleFilterCommand());
        jda.addEventListener(new SpamFilterListener());
    }
}